var FPW = FPW || {
    'sitePositions': 'player_positions',
    'b': new Date(),
    'init': function() {
        var doc = document;
        var wData = doc.getElementById('fp-widget').dataset;

        FPW.height = wData.height;
        FPW.width = wData.width;
        FPW.tHC = wData.thead_color;
        FPW.tFC = wData.thead_font;
        FPW.tAC = wData.t_alt_row;
        FPW.tLC = wData.link_color;
        FPW.pC = wData.pill_color;
        FPW.sport = wData.sport;
        FPW.wtype = wData.wtype.toUpperCase();
        FPW.expert = wData.expert;
        FPW.affiliateCode = wData.affiliate_code;
        FPW.expertData = {};
        FPW.filters = wData.filters;
        FPW.week = wData.week;
        FPW.year = wData.year;
        FPW.scr = wData.scoring;
        FPW.auction = wData.auction;
        FPW.notes = wData.notes;
        FPW.tags = wData.tags;
        FPW.output = wData.output;
        FPW.cards = (typeof wData.cards !== 'undefined') ? wData.cards : 'false';
        FPW.format = wData.format;
        FPW.positions = wData.positions.split(':');
        // The categories bucket as the embed was built, before any fallback rewrites
        // wData.positions. Scoring decisions key off this; FPW.positions is the runtime
        // list and may end up holding another bucket's positions.
        FPW.cats_pos = FPW.positions;
        FPW.ppr_pos = (typeof wData.ppr_positions !== 'undefined') ? wData.ppr_positions.split(':') : [];
        FPW.showPodcastIcons = (typeof wData.showpodcasticons !== 'undefined') ? wData.showpodcasticons : false;
        FPW.ecrOnly = (typeof wData.ecronly !== 'undefined');
        FPW.rankLimit = (typeof wData.ranklimit !== 'undefined') ? wData.ranklimit : -1;
        FPW.host = (typeof wData.host !== 'undefined') ? wData.host : '';
        FPW.titleHeader = (typeof wData.title_header !== 'undefined') ? wData.title_header : '';
        FPW.showVsECR = (typeof wData.showvsecr !== 'undefined') ? wData.showvsecr === 'true' : true;
        FPW.hideExpertColumns = wData.hide_expert_columns == 'true';
        FPW.hideExpertsColumnValue = '000'; // use a numeric value to treat it as an expert column, and group it with FP all experts columns

        if (typeof wData.half_positions !== 'undefined') {
            FPW.half_pos = wData.half_positions.split(':');
        } else {
            FPW.half_pos = [];
        }

        if (typeof wData.pts_positions !== 'undefined') {
            FPW.pts_pos = wData.pts_positions.split(':');
        } else {
            FPW.pts_pos = [];
        }

        // NBA High Score / 9-Cat. The 9-Cat attribute is nine_cat_positions, not
        // 9cat_positions, because a data attribute starting with a digit does not
        // round-trip reliably through dataset, which is how all of wData is read.
        if (typeof wData.highscore_positions !== 'undefined') {
            FPW.highscore_pos = wData.highscore_positions.split(':');
        } else {
            FPW.highscore_pos = [];
        }

        if (typeof wData.nine_cat_positions !== 'undefined') {
            FPW.nine_cat_pos = wData.nine_cat_positions.split(':');
        } else {
            FPW.nine_cat_pos = [];
        }

        FPW.eleg = wData.eleg;
        if (['6', '7', '8', '9', '159', '285', '1054', '1663'].indexOf(FPW.expert) !== -1 && (FPW.sport === 'MLB' || FPW.sport === 'NFL')) {
            FPW.eleg = 'Y';
        }

        FPW.adp = null;
        FPW.multiPos = ['ALL', 'FLX', 'OP', 'IDP', 'OL', 'DL', 'DB', 'OT', 'OG', 'IOL', 'OL', 'IDL', 'EDGE'];
        FPW.hideADP = ['HC', 'P', 'TK', 'TQB', 'TRB', 'TWR', 'TTE', 'TOL'];
        FPW.promoLink = false;
        if (wData.promo_link !== 'false' && FPW.sport !== 'NHL') {
            if ((FPW.wtype === 'PRESEASON' || FPW.wtype === 'DK' || FPW.week == 0) && FPW.wtype.indexOf('ROS') === -1) {
                if (window.location.protocol !== 'https:') {
                    FPW.promoLink = {
                        title: 'Start a Mock Draft Now',
                        link: 'https://draftwizard.fantasypros.com/simulator/?sport=' + FPW.sport.toLowerCase()
                    };
                }
            } else {
                FPW.promoLink = {
                    title: 'View Available Players',
                    link: 'https://www.fantasypros.com/' + FPW.sport.toLowerCase() + '/myplaybook/available-players.php?'
                };
            }
        }

        FPW.playerCardRun = 0;

        if (FPW.eleg === 'Y') {
            FPW.sitePositions = 'player_yahoo_positions';
        } else if (FPW.sport === 'NFL' && (FPW.wtype == 'ST' || FPW.wtype == 'WEEKLY' || FPW.wtype == 'ROS')) {
            FPW.sitePositions = 'player_eligibility';
        }

        FPW.theAthletic = ['6', '406', '487', '789'].indexOf(FPW.expert) !== -1;
        if ((FPW.sport === 'NFL' || FPW.sport === 'NCAAF') && ['9', '159', '1054', '1663'].indexOf(FPW.expert) !== -1) {
            FPW.yahoo = true;
            FPW.siteName = 'Yahoo';
            // wData.positions =  wData.half_positions;
            if (FPW.scr == 'STD' || FPW.scr === '') {
                FPW.scr = 'HALF';
            }

        } else if (wData.positions === '' && typeof wData.ppr_positions !== 'undefined' && wData.ppr_positions !== '') {
            wData.positions = wData.ppr_positions;
            FPW.scr = 'PPR';
        } else if (wData.positions === '' && FPW.half_pos.length > 0) {
            wData.positions = wData.half_positions;
            FPW.scr = 'HALF';
        }

        if (typeof wData.pts_positions !== 'undefined') {
            if (wData.positions === '' && wData.pts_positions.split(':') !== '') {
                wData.positions = wData.pts_positions;
                FPW.scr = 'PTS';
            }
        }

        // An embed built only from High Score or 9-Cat positions has no cats bucket to
        // fall back on, so it would render empty without this.
        if (wData.positions === '' && typeof wData.highscore_positions !== 'undefined' && wData.highscore_positions !== '') {
            wData.positions = wData.highscore_positions;
            FPW.scr = 'HIGHSCORE';
        } else if (wData.positions === '' && typeof wData.nine_cat_positions !== 'undefined' && wData.nine_cat_positions !== '') {
            wData.positions = wData.nine_cat_positions;
            FPW.scr = '9CAT';
        }

        // Re-read after the fallbacks above. The cheatsheet format drives its requests
        // from FPW.positions, so a stale snapshot would issue none at all.
        FPW.positions = wData.positions.split(':');

        FPW.tabPositions = new Set();
        let positionOrder = {
            'NFL': ['ALL', 'QB', 'RB', 'WR', 'TE', 'FLX', 'OP', 'DST', 'K', 'IDP', 'DL', 'IDL', 'DE', 'EDGE', 'DT', 'LB', 'DB', 'CB', 'S', 'OT', 'IOL', 'OG', 'C', 'P', 'RK', 'TQB', 'TRB', 'TWR', 'TTE', 'TK', 'HC', 'TOL', '1', '2', '3', '4', '5', '6', '7'],
            'MLB': ['ALL', 'H', 'P', 'C', '1B', '2B', '3B', 'SS', 'OF', 'LF', 'CF', 'RF', 'DH', 'SP', 'RP'],
            'NBA': ['ALL', 'PG', 'SG', 'SF', 'PF', 'G', 'F', 'C', 'FC'],
            'NHL': ['ALL', 'C', 'LW', 'RW', 'D', 'G'],
            'NCAAF': ['ALL', 'QB', 'RB', 'WR', 'TE', 'FLX', 'OP', 'DST', 'OFF', 'K', 'IDP', 'DL', 'IDL', 'DE', 'EDGE', 'DT', 'LB', 'DB', 'CB', 'S', 'OT', 'IOL', 'OG', 'C', 'P', 'RK', 'TQB', 'TRB', 'TWR', 'TTE', 'TK', 'HC', 'TOL', '1', '2', '3', '4', '5', '6', '7'],
        };

        if (FPW.sport === 'NFL' && FPW.wtype === 'POWER') {
            positionOrder[FPW.sport] = ['TM', 'OFF', 'DEF', 'SQB', 'RBS', 'WRTE', 'OL', 'DL', 'OBLB', 'SEC'];
        }

        for (const position of positionOrder[FPW.sport]) {
            for (const position_type of ['positions', 'ppr_positions', 'half_positions', 'pts_positions', 'highscore_positions', 'nine_cat_positions']) {
                if (wData[position_type] && !wData[position_type].split(':').includes(position) || !wData[position_type]) continue;

                FPW.tabPositions.add(position);
            }
        }

        FPW.pos = [...FPW.tabPositions][0];
        if (FPW.tabPositions.size === 1) {
            FPW.tabPositions = false;
        }

        var filters;
        switch (FPW.sport + FPW.wtype) {
            case 'MLBPRESEASON':
                FPW.header = this.year + ' Preseason Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                if (FPW.auction === 'true') {
                    this.columns.splice(2, 2, ['Auction', 'auction'], ['vs. AAV', 'rank_vs_aav']);
                }
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Position', 'position', 'small-col']];
                break;
            case 'MLBROS':
                FPW.header = FPW.year + ' Rest of Season Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Position', 'position', 'small-col']];
                break;
            case 'MLBWEEKLY':
                FPW.header = FPW.year + ' Week ' + FPW.week + ' Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Position', 'position', 'small-col']];
                break;
            case 'MLBDK':
                FPW.header = FPW.year + ' Keeper/Dynasty Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player, Age (team)', 'player_name:player_page_url:\', \'+player[\'player_age\']+\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[\'player_age\']+\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'position', 'small-col']];
                break;
            case 'MLBST':
                FPW.header = FPW.year + ' Fantasy Baseball Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'MLBSTROS':
                FPW.header = FPW.year + ' Rest of Season Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'MLBSTK':
                FPW.header = FPW.year + ' Dynasty Baseball Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'MLBPROSPECT':
                FPW.header = this.year + ' Prospect Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Position', 'position', 'small-col']];
                break;
            case 'NFLPRESEASON':
                FPW.header = FPW.year + ' Draft Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col'],
                    ['vs. ADP', 'rank_vs_adp', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'NFLBEST':
                FPW.header = FPW.year + ' Best Ball Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col'],
                    ['vs. ADP', 'rank_vs_adp', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'NFLSTBEST':
                FPW.header = FPW.year + ' Best Ball Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' \'+ player[\'player_bye_week\'] +\')\'', 'name-col'],
                ];
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLSLEEPERS':
                FPW.header = FPW.year + ' Sleeper Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col'],
                    ['vs. ADP', 'rank_vs_adp', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'NFLWEEKLY':
                FPW.header = 'Fantasy Football Rankings - Week ' + FPW.week;
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['Matchup', 'matchup', 'matchup-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' (\'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.multiBlogFormat = '\' (\'+ player[FPW.sitePositions] +\', \'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.extraCols = 1;
                FPW.extraCol = [3, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NFLROS':
                FPW.header = FPW.year + ' Rest of Season Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['Bye', 'bye_week', 'small-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'';
                if (FPW.week > 18) {
                    FPW.header = FPW.year + ' Rest of Playoff Rankings';
                    FPW.columns = [
                        ['#', 'rank', 'small-col rank-col'],
                        ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                        ['ECR&#8482', 'rank_ecr', 'small-col'],
                        ['vs. ECR', 'rank_vs_ecr', 'small-col']
                    ];
                    FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\']';
                }
                FPW.multiBlogFormat = FPW.blogFormat;
                break;
            case 'NFLDK':
                FPW.header = FPW.year + ' Dynasty Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player, Age (team/bye)', 'player_name:player_page_url:\', \'+player[\'player_age\']+\' (\'+ player[\'player_team_id\'] +\'/\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'NFLST':
                FPW.header = (FPW.week > 0) ? 'Fantasy Football Rankings - Week ' + FPW.week : FPW.year + ' Fantasy Football Draft Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                if (FPW.yahoo) {
                    filters.push('FP');
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col']
                ];
                FPW.extraCols = 0;
                if (FPW.week > 0) {
                    FPW.columns.push(['Matchup', 'player_opponent', 'matchup-col']);
                    FPW.extraCols = 1;
                    FPW.extraCol = [3, ['Pos', 'pos_rank', 'small-col']];
                }
                FPW.columns.push(filters);
                break;
            case 'NFLSTK':
                FPW.header = FPW.year + ' Dynasty Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'NFLSTROS':
                FPW.header = FPW.year + ' Rest of Season Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                ];
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLSTWW':
                FPW.header = 'Fantasy Football Waiver Wire Rankings - Week ' + FPW.week;
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                if (FPW.yahoo) {
                    filters.push('FP');
                }
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\']', 'name-col'],
                    ['Rost', 'player_owned_avg', 'small-col']
                ];
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLWW':
                FPW.header = 'Fantasy Football Waiver Wire Rankings - Week ' + FPW.week;
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>Team (Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'player_bye_week\'] +\')\'', 'name-col']
                ];

                if (FPW.ecrOnly) {
                    FPW.columns.push(['Best', 'rank_min', 'small-col']);
                    FPW.columns.push(['Worst', 'rank_max', 'small-col']);
                } else {
                    FPW.filters = FPW.expert;
                }

                FPW.columns.push(['Rost', 'player_owned_avg', 'small-col']);

                FPW.blogFormat = '\' \'+ player[\'player_team_id\'] +\' (Rost \'+ Math.round(player[\'player_owned_avg\']) +\'%)\'';
                FPW.multiBlogFormat = '\' \'+ player[\'player_team_id\'] +\' (\'+ player[FPW.sitePositions] +\', Rost \'+ Math.round(player[\'player_owned_avg\']) +\'%)\'';
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NFLPROSPECT':
                FPW.header = FPW.year + ' NFL Draft Big Board';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(School)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_college\'] +\')\'', 'name-col'],
                    ['<span title="Expert Consensus Rank">ECR&#8482</span>', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_college\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NFLSTPROSPECT':
                FPW.header = FPW.year + ' NFL Draft Big Board';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(School)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_college\'] +\')\'', 'name-col'],
                ];
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLMOCK':
                FPW.header = FPW.year + ' NFL Mock Draft';
                FPW.columns = [
                    ['Pick', 'pick_label', 'small-col rank-col'],
                    ['Team', 'pick_team_label', 'school-col'],
                    ['Player', 'player_name:player_page_url:\'\'', 'short-name-col'],
                    ['School', 'player_college', 'school-col'],
                    ['Pos', 'player_positions', 'small-col'],
                ];
                FPW.blogFormat = '\' (\'+player[FPW.sitePositions]+\' - \'+ player[\'player_college\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 0;
                break;
            case 'NFLDEVY':
                FPW.header = FPW.year + ' NFL Devy Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(School)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_college\'] +\')\'', 'name-col'],
                    ['Class', 'draft_class', 'small-col'],
                    ['<span title="Expert Consensus Rank">ECR&#8482</span>', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_college\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NFLSTDEVY':
                FPW.header = FPW.year + ' NFL Devy Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(School)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_college\'] +\')\'', 'name-col'],
                ];
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLROOKIES':
                FPW.header = FPW.year + ' NFL Dynasty Rookie Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['<span title="Expert Consensus Rank">ECR&#8482</span>', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_college\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NFLSTROOKIES':
                FPW.header = FPW.year + ' NFL Dynasty Rookie Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team)</small>', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                ];
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'pos_rank', 'small-col']];
                FPW.columns.push(filters);
                break;
            case 'NFLPOWER':
                FPW.header = FPW.year + ' NFL POWER RANKINGS';
                FPW.columnsByPosition = {
                    'TM': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['Team', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['Opp Rank', 'tm_opp_rank', 'small-col center-cell'],
                        ['Team Edge', 'tm_diff', 'small-col center-cell'],
                    ],
                    'OFF': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['Offense', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['DEF Rank', 'def_opp_rank', 'small-col center-cell'],
                        ['OFF Edge', 'def_diff', 'small-col center-cell'],
                    ],
                    'DEF': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['Defense', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['OFF Rank', 'off_opp_rank', 'small-col center-cell'],
                        ['DEF Edge', 'off_diff', 'small-col center-cell'],
                    ],
                    'SQB': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        //starting qb player name
                        ['Team', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['DEF Rank', 'def_opp_rank', 'small-col center-cell'],
                        ['QB-DEF Edge', 'def_diff', 'small-col center-cell'],
                        ['SEC Rank', 'sec_opp_rank', 'small-col center-cell'],
                        ['QB-SEC Edge', 'sec_diff', 'small-col center-cell'],
                    ],
                    'RBS': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['RB Unit', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['DL Rank', 'dl_opp_rank', 'small-col center-cell'],
                        ['RB-DL Edge', 'dl_diff', 'small-col center-cell'],
                        ['LB Rank', 'oblb_opp_rank', 'small-col center-cell'],
                        ['RB-LB Edge', 'oblb_diff', 'small-col center-cell'],
                    ],
                    'WRTE': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['WR/TE', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['Secondary Rank', 'sec_opp_rank', 'small-col center-cell'],
                        ['WR/TE Edge', 'sec_diff', 'small-col center-cell'],
                    ],
                    'OL': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['OL', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['DL Rank', 'dl_opp_rank', 'small-col center-cell'],
                        ['OL Edge', 'dl_diff', 'small-col center-cell'],
                    ],
                    'DL': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['DL', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['OL Rank', 'ol_opp_rank', 'small-col center-cell'],
                        ['DL Edge', 'ol_diff', 'small-col center-cell'],
                    ],
                    'OBLB': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['LB', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['RB Rank', 'rbs_opp_rank', 'small-col center-cell'],
                        ['LB Edge', 'rbs_diff', 'small-col center-cell'],
                    ],
                    'SEC': [
                        ['Rank', 'rank', 'small-col rank-col center-cell'],
                        ['Secondary', 'team_id', 'name-col'],
                        ['Opp', 'opp', 'small-col center-cell'],
                        ['WR/TE Rank', 'wrte_opp_rank', 'small-col center-cell'],
                        ['SEC Edge', 'wrte_diff', 'small-col center-cell'],
                    ],
                }
                break;
            case 'NBAPRESEASON':
                FPW.header = this.year + ' Draft' + FPW.scoringHeaderLabel() + ' Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[\'player_positions\'] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[\'player_positions\']+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'position', 'small-col']];
                break;
            case 'NBAROS':
                FPW.header = FPW.year + ' Rest of Season' + FPW.scoringHeaderLabel() + ' Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 0;
                break;
            case 'NBADK':
                FPW.header = FPW.year + ' Dynasty' + FPW.scoringHeaderLabel() + ' Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 0;
                break;
            case 'NBAST':
                FPW.header = FPW.year + ' Fantasy Basketball' + FPW.scoringHeaderLabel() + ' Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'NBASTROS':
                FPW.header = FPW.year + ' Rest of Season Basketball' + FPW.scoringHeaderLabel() + ' Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'NBASTK':
                FPW.header = FPW.year + ' Dynasty Basketball' + FPW.scoringHeaderLabel() + ' Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'NHLPRESEASON':
                FPW.header = this.year + ' Draft Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'position', 'small-col']];
                break;
            case 'NHLROS':
                FPW.header = FPW.year + ' Rest of Season Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    ['ECR&#8482;', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' (\'+ player[\'player_team_id\'] +\')\'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 0;
                break;
            case 'NHLST':
                FPW.header = FPW.year + ' Fantasy Hockey Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col'],
                    filters
                ];
                FPW.extraCols = 0;
                break;
            case 'NCAAFPRESEASON':
                FPW.header = FPW.year + ' Draft Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col'],
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'NCAAFWEEKLY':
                FPW.header = 'Fantasy NCAA Football Rankings - Week ' + FPW.week;
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['Matchup', 'matchup', 'matchup-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' (\'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.multiBlogFormat = '\' (\'+ player[FPW.sitePositions] +\', \'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.extraCols = 1;
                FPW.extraCol = [3, ['Pos', 'pos_rank', 'small-col']];
                break;
            case 'NCAAFST':
                FPW.header = (FPW.week > 0) ? 'Fantasy NCAA Football rankings - Week ' + FPW.week : FPW.year + ' Fantasy NCAA Football Draft Rankings';
                filters = FPW.filters.split(':');
                if (FPW.hideExpertColumns) {
                    filters = [FPW.hideExpertsColumnValue];
                }
                // if (FPW.yahoo) {
                //     filters.push('FP');
                // }
                FPW.columns = [
                    ['#', 'rank_ecr', 'small-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\' - \'+ player[FPW.sitePositions] +\')\'', 'name-col']
                ];
                FPW.extraCols = 0;
                if (FPW.week > 0) {
                    FPW.columns.push(['Matchup', 'player_opponent', 'matchup-col']);
                    FPW.extraCols = 1;
                    FPW.extraCol = [3, ['Pos', 'pos_rank', 'small-col']];
                }
                FPW.columns.push(filters);
                break;
            case 'AAFPRESEASON':
                FPW.header = FPW.year + ' AAF Draft Rankings';
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player <small>(Team/Bye)</small>', 'player_name:player_page_url:\' \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\')\'', 'name-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col'],
                    ['vs. ADP', 'rank_vs_adp', 'small-col']
                ];
                FPW.blogFormat = '\' \'+player[FPW.sitePositions]+\' - \'+ player[\'player_team_id\'] +\' (\'+ player[\'bye_week\'] +\'), \'+ ((player[\'rank_vs_ecr\'] > -1) ? \'+\' + player[\'rank_vs_ecr\'] : player[\'rank_vs_ecr\']) + \' vs. ECR \'';
                FPW.multiBlogFormat = FPW.blogFormat;
                FPW.extraCols = 1;
                FPW.extraCol = [2, ['Pos', 'player_positions', 'small-col']];
                break;
            case 'AAFWEEKLY':
                FPW.header = 'AAF Fantasy Football Rankings - Week ' + FPW.week;
                FPW.columns = [
                    ['#', 'rank', 'small-col rank-col'],
                    ['Player (team)', 'player_name:player_page_url:\' (\'+ player[\'player_team_id\'] +\')\'', 'name-col'],
                    ['Matchup', 'matchup', 'matchup-col'],
                    ['ECR&#8482', 'rank_ecr', 'small-col'],
                    ['vs. ECR', 'rank_vs_ecr', 'small-col']
                ];
                FPW.blogFormat = '\' (\'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.multiBlogFormat = '\' (\'+ player[FPW.sitePositions] +\', \'+ player[\'player_team_id\'] +\' \'+player[\'matchup\']+\')\'';
                FPW.extraCols = 1;
                FPW.extraCol = [3, ['Pos', 'pos_rank', 'small-col']];
                break;
        }

        if (FPW.tags === 'true') {
            FPW.columns.push(['TAG', 'player_tag', 'tag-col']);
        }
        if (FPW.notes === 'true') {
            if (FPW.wtype.indexOf('ST') !== -1 && FPW.wtype !== 'BEST' || FPW.wtype === 'WW') {
                FPW.columns.push(['Notes', 'note', 'notes-col no-sort']);
            } else {
                FPW.columns.push(['Notes', 'notes', 'notes-col no-sort']);
            }
        }

        if (!doc.getElementById('fp-widget-style')) {
            FPW.CSS(FPW.height, FPW.width, FPW.tHC, FPW.tFC, FPW.tAC, FPW.tLC, FPW.pC);
        }

        FPW.build();

        var isInIframe = (parent !== window);

        if (isInIframe && !document.referrer.match(/fantasypros.com|fp.dev|fp.test/)) {
            var date = new Date();
            date.setMinutes(date.getMinutes() + 10);

            document.cookie = 'fp-widget-referrer=' + document.referrer + '; domain=fantasypros.com; expires=' + date.toGMTString() + '; path=/';
            document.cookie = 'fp-widget-type=' + FPW.sport + FPW.wtype + '; domain=fantasypros.com; expires=' + date.toGMTString() + '; path=/';
        }
    },
    'build': function() {
        var doc = document;

        var wContainer = FPW.create('div', 'fp-widget-content', false, document.getElementById('fp-widget'));
        var wHeader = FPW.create('div', 'fp-widget-header', false, wContainer);
        if (FPW.titleHeader !== 'false') {
            var wTitle = FPW.create('h4', 'fp-widget-title', 'pull-left', wHeader);
            wTitle.innerHTML = FPW.header;
        }

        if (FPW.promoLink) {
            var wPromoLink = FPW.create('a', false, 'pull-right', wHeader);
            wPromoLink.href = FPW.promoLink.link;
            if (FPW.affiliateCode !== '') {
                wPromoLink.href += '&partner=' + FPW.affiliateCode;
            }
            wPromoLink.target = '_blank';
            wPromoLink.innerHTML = FPW.promoLink.title;
        }

        FPW.create('div', false, 'clearfix', wHeader);

        var wBody = FPW.create('div', 'fp-widget-body', false, wContainer);

        if (FPW.tabPositions && FPW.format !== 'cheatsheet') {
            FPW.createFPTabs();
        }

        var subDiv = FPW.create('div', 'fp-widget-subDiv', false, wBody);

        FPW.create('div', 'fp-widget-pubDate', 'pull-right', subDiv);

        if (FPW.sport === 'NCAAF') {
            FPW.cards = false;
        }

        if (FPW.sport === 'NFL' || FPW.sport === 'NCAAF') {
            FPW.createPPRradio();
        }
        if (FPW.sport === 'NBA') {
            FPW.createPTSradio();
        }

        if (FPW.sport === 'MLB' && FPW.eleg !== 'Y' && FPW.format !== 'cheatsheet') {
            FPW.createSiteEldg();
        }

        FPW.create('div', false, 'clearfix', subDiv);

        FPW.create('div', 'fp-widget-table', false, wBody);

        FPW.getRankings();

        if (FPW.cards === 'true') {
            window.pfsport = FPW.sport.toLowerCase();
            var pcConfig = FPW.create('script', 'fpw-pc-config');
            pcConfig.innerHTML = 'window.PLAYERCARDS_CONFIG={hideRankTab:true';

            if (FPW.affiliateCode !== '') {
                pcConfig.innerHTML += ',affiliateCode:\'' + FPW.affiliateCode + '\'';
            }

            if (FPW.showPodcastIcons == 'true') {
                pcConfig.innerHTML += ',showPodcastIcons:true';
                var soundCloudScript = FPW.create('script');
                soundCloudScript.src = 'https://w.soundcloud.com/player/api.js';
            }

            pcConfig.innerHTML += '};';

            var pcScript = FPW.create('script', 'greaseballjs');
            if (FPW.sport === 'NFL' || FPW.sport === 'MLB') {
                pcScript.src = '//cdn.fantasypros.com/playercards/v3/source.js' + '?' + FPW.b.getFullYear() + FPW.b.getMonth() + FPW.b.getDate();
            } else {
                pcScript.src = '//cdn.fantasypros.com/playercards/source.js' + '?' + FPW.b.getFullYear() + FPW.b.getMonth() + FPW.b.getDate();
            }

            if (doc.head.contains(doc.getElementById('greaseballjs'))) {
                doc.getElementsByTagName('head')[0].replaceChild(pcScript, doc.getElementById('greaseballjs'));
                doc.getElementsByTagName('head')[0].replaceChild(pcConfig, doc.getElementById('fpw-pc-config'));
            } else {
                doc.getElementsByTagName('head')[0].appendChild(pcConfig);
                doc.getElementsByTagName('head')[0].appendChild(pcScript);
                if (FPW.showPodcastIcons == 'true') {
                    doc.getElementsByTagName('head')[0].appendChild(soundCloudScript);
                }
            }
        }
    },
    'getRankings': function() { // Make JSONP call to get ranking data
        var doc = document;
        if (FPW.format === 'cheatsheet') {
            var cheatSheetDiv = FPW.create('div', 'fp-pos-cs', false, doc.getElementById('fp-widget-table'));

            var posScript;

            FPW.posDiv = {};

            ['ALL', 'FLX', 'QB', 'WR', 'RB', 'TE', 'K', 'DST', 'OFF', 'TQB', 'TRB', 'TWR', 'TTE', 'TK', 'TOL', 'HC', 'OL', 'H', 'P', 'C', '1B', '2B', '3B', 'SS', 'OF', 'DH', 'G', 'F', 'FC', 'PG', 'SG', 'SF', 'PF', 'LW', 'RW', 'D', 'OP'].forEach(function(pos) {
                if (FPW.positions.indexOf(pos) > -1) {
                    FPW.create('div', 'fpw-cs-pos-div-' + pos, 'fpw-cs-pos-div', cheatSheetDiv);

                    posScript = FPW.create('script', 'fpw-rankings-call-' + pos);
                    const params = {
                        'sport': FPW.sport,
                        'year': FPW.year,
                        'week': FPW.week,
                        'id': FPW.expert,
                        'position': pos,
                        'type': FPW.wtype,
                        'scoring': FPW.scr,
                        'callback': 'FPW.rankingsCB'
                    }
                    posScript.src = FPW.buildURL('/api/v1/expert-rankings.php', params);

                    if (doc.head.contains(doc.getElementById('fpw-rankings-call-' + pos))) {
                        doc.getElementsByTagName('head')[0].replaceChild(posScript, doc.getElementById('fpw-rankings-call-' + pos));
                    } else {
                        doc.getElementsByTagName('head')[0].appendChild(posScript);
                    }
                }
            });
        } else {
            let cbScript = FPW.create('script', 'fpw-rankings-call');
            cbScript.src = FPW.buildRankingsURL();

            if (doc.head.contains(doc.getElementById('fpw-rankings-call'))) {
                doc.getElementsByTagName('head')[0].replaceChild(cbScript, doc.getElementById('fpw-rankings-call'));
            } else {
                doc.getElementsByTagName('head')[0].appendChild(cbScript);
            }

        }
    },
    'loadSortScript': function(url, cb) {
        var sortScript = FPW.create('script', 'fpw-sort', false, document.getElementsByTagName('head')[0]);
        sortScript.src = url;
        sortScript.onload = function() {
            cb();
        };
    },
    'createTableSort': function(table) {
        var doc = document;
        /* global Tablesort */
        FPW.sort = new Tablesort(table[0], {
            empyToBottom: true
        });

        table[0].addEventListener('afterSort', function() {
            if (FPW.sort.current.className.split(' ').indexOf('rank-col') !== -1) {
                doc.querySelectorAll('.fp-widget-tier').forEach(function(ele) {
                    ele.parentNode.style.display = 'table-row';
                });
            } else {
                doc.querySelectorAll('.fp-widget-tier').forEach(function(ele) {
                    ele.parentNode.style.display = 'none';
                });
            }
        });
    },
    'rankingsCB': function(data) { //Handle the JSONP callback from getRankings and call buildFPTable or buildFPBlog. Append or replace results to widget body.

        const doc = document;
        let wTables = doc.getElementById('fp-widget-table');
        let pubDate = doc.getElementById('fp-widget-pubDate');
        let params;

        FPW.callbackData = data;
        switch (FPW.format) {
            case 'blog': {
                let blog = FPW.buildFPBlog(data);
                wTables.appendChild(blog[0]);

                params = {
                    sport: FPW.sport,
                    year: FPW.year,
                    week: FPW.week,
                    id: FPW.expert,
                    position: FPW.pos,
                    type: FPW.wtype,
                    notes: FPW.notes,
                    scoring: FPW.scr,
                    export: 'xls'
                }
                pubDate.innerHTML = `(Updated ${blog[1]}) <a href="${FPW.buildURL('/api/v1/expert-rankings.php', params)}" rel="nofollow"><img style="vertical-align:top;" width="16px;" src="https://images.fantasypros.com/images/icons/export.png"/></a>`;
                FPW.playerCardRun++;
                break;
            }
            case 'cheatsheet':
                FPW.buildFPCheatsheet(data);
                FPW.playerCardRun++;
                break;
            case 'HTML':
                if (doc.getElementById('raw-html-box')) {
                    wTables.appendChild(FPW.buildFPTable(data)[0]);
                    var htmlOutput = doc.getElementById('fp-widget').outerHTML + doc.querySelector('.fpw-footer').outerHTML;
                    doc.getElementById('raw-html-box').innerHTML = '<textarea rows="3" style="resize:none; margin-bottom:0; width:90%;" onclick="this.select();" readonly>' + htmlOutput.replace(/™/g, '') + '</textarea>';
                }
                break;
            default: {
                let table = FPW.buildFPTable(data);
                wTables.appendChild(table[0]);

                if (typeof Tablesort === 'undefined') {
                    FPW.loadSortScript('//cdn.fantasypros.com/js/fp-tablesort-1.0.min.js', function() {
                        FPW.createTableSort(table)
                    });
                } else {
                    FPW.createTableSort(table);
                }

                if (FPW.ecrOnly) {
                    pubDate.innerHTML = 'Consensus of ' + data.ecr_count + ' experts&nbsp;';
                }

                if (FPW.wtype === 'POWER') {
                    const apiUpdatedParts = data.updated.split(' ');
                    const publishDate = new Date(`${apiUpdatedParts[0]}T${apiUpdatedParts[1]}Z`);
                    pubDate.innerHTML = `Updated: ${publishDate.getMonth() + 1}/${publishDate.getDate()}`;
                } else if (FPW.yahoo) {
                    params = {
                        'sport': FPW.sport,
                        'year': FPW.year,
                        'week': FPW.week,
                        'id': FPW.expert,
                        'position': FPW.pos,
                        'type': FPW.wtype,
                        'scoring': FPW.scr,
                        'filters': FPW.filters,
                        'export': 'csv'
                    }
                    var iframe_target = '';
                    if (window.self !== window.top) {
                        iframe_target = ' target="_blank"';
                    }
                    pubDate.innerHTML = `<a href="${FPW.buildURL('/api/v1/consensus-rankings.php', params)}" rel="nofollow" ${iframe_target}>Download</a>`;
                } else if (FPW.wtype.indexOf('ST') === -1) {
                    params = {
                        'sport': FPW.sport,
                        'year': FPW.year,
                        'week': FPW.week,
                        'id': FPW.expert,
                        'position': FPW.pos,
                        'type': FPW.wtype,
                        'notes': FPW.notes,
                        'scoring': FPW.scr,
                        'export': 'csv'
                    }
                    pubDate.innerHTML = `(Updated ${table[1]}) <a href="${FPW.buildURL('/api/v1/expert-rankings.php', params)}" rel="nofollow"><img style="vertical-align:middle;" width="16px;" src="https://images.fantasypros.com/images/icons/export.png"/></a>`;
                } else {
                    params = {
                        'sport': FPW.sport,
                        'year': FPW.year,
                        'week': FPW.week,
                        'id': FPW.expert,
                        'position': FPW.pos,
                        'type': FPW.wtype,
                        'scoring': FPW.scr,
                        'filters': FPW.filters,
                        'export': 'csv'
                    }
                    var iframe_target = '';
                    if (window.self !== window.top) {
                        iframe_target = ' target="_blank"';
                    }
                    pubDate.innerHTML = `<a href="${FPW.buildURL('/api/v1/consensus-rankings.php', params)}" rel="nofollow" ${iframe_target}>Download</a>`;
                }
                FPW.playerCardRun++;
            }
        }
        if (typeof playercardGenerator !== 'undefined' && FPW.cards === 'true') {
            playercardGenerator.clearAll();
            playercardGenerator.run();
        }
    },
    'buildFPTable': function(data) { // Build rankings table after rankingsCB widget in table style.
        var doc = document;
        var table, tbody, thead, cell, exists, a;

        if (doc.getElementById('fpPosTable')) {
            table = doc.getElementById('fpPosTable');

            thead = table.tHead;
            thead.innerHTML = '';

            tbody = table.tBodies[0];
            tbody.innerHTML = '';
            exists = true;
        } else {
            table = FPW.create('table', 'fpPosTable', 'table table-bordered table-condensed table-striped table-hover player-table table-full');
            thead = table.createTHead();
            tbody = FPW.create('tbody', false, false, table);
            exists = false;
        }

        var thRow = thead.insertRow(0);

        //Check if extra "position" columns needs to be added or removed.
        if (FPW.extraCols === 1 && (FPW.multiPos.indexOf(FPW.pos) !== -1) && FPW.columns[FPW.extraCol[0]] !== FPW.extraCol[1]) {
            FPW.addColumn(FPW.extraCol[0], FPW.extraCol[1]);
        } else if (FPW.extraCols === 1 && (FPW.multiPos.indexOf(FPW.pos) === -1) && FPW.columns[FPW.extraCol[0]] === FPW.extraCol[1]) {
            FPW.removeColumn(FPW.extraCol[0]);
        }

        if (FPW.sport === 'NFL' && !data.available_adp) {
            FPW.hideADP.push(FPW.pos);
        }

        const columnsForHeader = FPW.wtype === 'POWER' ? FPW.columnsByPosition[FPW.pos] : FPW.columns;
        columnsForHeader.forEach(function(title) {
            if ((FPW.wtype.indexOf('ST') !== -1) && /^\d+$/.test(title[0])) {
                for (var i = 0; i < title.length; i++) {
                    if (typeof data.expert_pub[title[i]] !== 'undefined') {
                        cell = FPW.create('th', false, false, thRow);
                        a = FPW.create('a', false, 'expert-name', cell);
                        a.href = 'https://twitter.com/' + data.expert_twitter[title[i]];
                        a.target = '_blank';
                        a.innerHTML = data.expert_names[title[i]];
                        var span = FPW.create('span', false, false, cell);
                        span.innerHTML = FPW.getPubDate(data.expert_pub[title[i]], 'short');
                        cell.setAttribute('data-sort-method', 'number');
                    } else if (title[i] === 'FP') {
                        cell = FPW.create('th', false, false, thRow);
                        cell.style.fontSize = '10px';
                        a = FPW.create('a', false, 'expert-name', cell);
                        a.href = 'https://www.fantasypros.com/nfl/rankings/consensus-cheatsheets.php';
                        a.target = '_blank';
                        a.innerHTML = 'FPROS All Experts';
                        cell.setAttribute('data-sort-method', 'number');
                    } else if (title[i] === FPW.hideExpertsColumnValue) {
                        cell = FPW.create('th', false, false, thRow);

                        var cellName = 'Consensus<br>Rankings';
                        if (FPW.siteName) cellName = FPW.siteName + ' ' + cellName;

                        cell.innerHTML = cellName
                        cell.className = 'sort-default';
                        cell.setAttribute('data-sort-method', 'number');
                    }
                }
            } else {
                cell = FPW.create('th', false, false, thRow);
                cell.innerHTML = title[0];
                cell.className = title[2];
                if (['rank', 'rank_ecr', 'rank_adp'].indexOf(title[1]) !== -1) {
                    if (title[1] === 'rank') {
                        cell.className += ' sort-default';
                    }
                    cell.setAttribute('data-sort-method', 'number');
                }
                if (title[1] === 'player_owned_avg') {
                    var tooltip = FPW.create('span', false, false, cell);
                    tooltip.setAttribute('title', 'Consensus Roster %');
                }
                //Hide ADP for NFL Positions that do not have it
                if (title[1] === 'rank_vs_adp' && FPW.hideADP.indexOf(FPW.pos) !== -1 && FPW.sport === 'NFL') {
                    cell.className += ' hide';
                }

                if (['NFL', 'MLB', 'NBA'].includes(FPW.sport) && title[1] === 'rank_vs_ecr' && !FPW.showVsECR) {
                    cell.className += ' hide';
                }
            }
        });

        var z = 0;
        var tier = 0;
        var tbRow;
        if (FPW.wtype !== 'POWER') {
            data.players.forEach(function(player) {
                if (FPW.rankLimit === -1 || z < FPW.rankLimit) {
                    if (typeof player.tier !== 'undefined' && player.tier !== tier && player.tier && player.tier.length !== 0) {
                        tbRow = tbody.insertRow(-1);
                        var cell = tbRow.insertCell(0);
                        cell.colSpan = FPW.columns.length;
                        cell.className = 'fp-widget-tier';
                        cell.setAttribute('data-sort', z);
                        cell.appendChild(doc.createTextNode('Tier ' + player.tier));
                        tier = player.tier;
                    }
                    var playerPosKey = player[FPW.sitePositions] ? FPW.sitePositions : 'player_positions';
                    if (player[playerPosKey] &&
                        (['ALL', 'FLX', 'OP', 'RK', 'IDP', 'DL', 'OL', 'DB', 'H', 'P', 'G', 'F', 'OT', 'OG', 'IOL', 'OL', 'IDL', 'EDGE'].indexOf(FPW.pos) !== -1 ||
                            (player[playerPosKey].split(',').indexOf(FPW.pos) !== -1 ||
                                (FPW.pos === 'LB' && (player[playerPosKey].split(',').indexOf('ILB') !== -1 ||
                                    player[playerPosKey].split(',').indexOf('OLB') !== -1)) ||
                                (FPW.pos === 'OF' && (player[playerPosKey].split(',').indexOf('CF') !== -1 ||
                                    player[playerPosKey].split(',').indexOf('LF') !== -1 ||
                                    player[playerPosKey].split(',').indexOf('RF') !== -1 ||
                                    player[playerPosKey].split(',').indexOf('OF') !== -1))))) {
                        tbRow = tbody.insertRow(-1);
                        z++;
                        FPW.columns.forEach(function(pData, y) {
                            var cell;
                            if (y === 0) {
                                cell = tbRow.insertCell(y);
                                cell.className = 'center-cell';
                                let rankVal = FPW.ecrOnly ? player.rank_ecr : z;
                                cell.appendChild(doc.createTextNode(rankVal));
                            } else if (y === 1) {
                                cell = tbRow.insertCell(y);
                                cell.className = 'fp-player-name-cell';
                                var a = FPW.create('a', false, false, cell);
                                if (FPW.yahoo && FPW.pos === 'DST') {
                                    var team_id = FPW.yahooTeam(player.player_team_id.toLowerCase());
                                    a.href = 'https://sports.yahoo.com/' + FPW.sport.toLowerCase() + '/teams/' + team_id + '/stats/';
                                } else {
                                    a.href = (FPW.yahoo) ? 'https://sports.yahoo.com/' + FPW.sport.toLowerCase() + '/players/' + player.player_yahoo_id : player[pData[1].split(':')[1]];
                                }
                                if (FPW.affiliateCode !== '' && !FPW.yahoo) {
                                    a.href += '?partner=' + FPW.affiliateCode;
                                }
                                a.target = '_blank';
                                if (pData[1].split(':')[0] === 'player_name' && (FPW.theAthletic && window.innerWidth < 600) && typeof player['player_short_name'] !== 'undefined') {
                                    a.innerHTML = player['player_short_name'];
                                } else {
                                    a.innerHTML = player[pData[1].split(':')[0]];
                                }

                                var team = FPW.create('span', false, 'player-team', cell);
                                team.innerHTML = eval(pData[1].split(':')[2]).replace('null', '').replace('()', '');

                                if (FPW.cards == 'true') {
                                    var playerCardsA = FPW.create('a');
                                    playerCardsA.href = '#';
                                    playerCardsA.className = 'fp-player-link fp-id-' + player.player_id;
                                    playerCardsA.setAttribute('fp-player-name', player.player_name);
                                    cell.appendChild(playerCardsA);
                                }
                            } else if (y === 2 && FPW.pos === 'ALL' && FPW.wtype.indexOf('ST') === -1 && FPW.wtype !== 'ROS') {
                                cell = tbRow.insertCell(y);
                                var ovPos;
                                if (FPW.sport === 'MLB') {
                                    ovPos = (player[playerPosKey].indexOf('P') !== -1) ? 'P' : 'H';
                                } else if (FPW.sport === 'NBA') {
                                    ovPos = player['player_sd_positions'];
                                } else if (pData.length > 1 && pData[1] == 'pos_rank' && 'pos_rank' in player) {
                                    ovPos = player['pos_rank'];
                                } else {
                                    ovPos = player[playerPosKey];
                                }
                                cell.appendChild(doc.createTextNode(ovPos));
                                cell.className = 'center-cell';
                            } else if ((FPW.wtype.indexOf('ST') !== -1) && /^\d+$/.test(pData[0])) { //Expert columns start
                                for (var i = FPW.columns[y].length - 1; i >= 0; i--) {
                                    if (typeof data.expert_pub[FPW.columns[y][i]] !== 'undefined') {
                                        cell = tbRow.insertCell(y);
                                        cell.className = 'center-cell';
                                        if (player.experts !== null && typeof player.experts[String(FPW.columns[y][i])] !== 'undefined') {
                                            cell.appendChild(doc.createTextNode(player.experts[String(FPW.columns[y][i])]));
                                        } else {
                                            cell.appendChild(doc.createTextNode(''));
                                        }
                                    } else if (FPW.columns[y][i] === 'FP') {
                                        cell = tbRow.insertCell(y);
                                        a = FPW.create('a', false, false, cell);
                                        a.href = player.player_page_url;
                                        if (FPW.affiliateCode !== '') {
                                            a.href += '?partner=' + FPW.affiliateCode;
                                        }
                                        a.target = '_blank';
                                        a.innerHTML = 'view';
                                        cell.className = 'center-cell';
                                    } else if (FPW.columns[y][i] === FPW.hideExpertsColumnValue) {
                                        cell = tbRow.insertCell(y);
                                        cell.className = 'center-cell';
                                        let rankVal = FPW.ecrOnly ? player.rank_ecr : z;
                                        cell.appendChild(doc.createTextNode(rankVal));
                                    }
                                }
                            } else if (pData[0] === 'Notes' && FPW.notes === 'true') {
                                cell = tbRow.insertCell(y);
                                if (player[pData[1]] !== '' && typeof player[pData[1]] !== 'undefined') {
                                    cell.className = 'fpw-note-cell';
                                    cell.innerHTML = player[pData[1]];

                                    var note = FPW.create('div', false, 'fpw-notes', cell);
                                    note.innerHTML = player[pData[1]];
                                }
                            } else if (pData[0] === 'TAG') {
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(player.tag.charAt(0).toUpperCase() + player.tag.slice(1)));
                                cell.className = 'center-cell tag-cell';
                                if (player.tag != '') {
                                    cell.className += ' ' + player.tag;
                                }
                            } else if (pData[0] === 'Rost') {
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(Math.round(player[pData[1]]) + '%'));
                                cell.className = 'center-cell';
                            } else if (y === 2 && FPW.pos === 'ALL' && FPW.sport === 'MLB' && FPW.wtype === 'ROS') {
                                cell = tbRow.insertCell(y);
                                ovPos = player[playerPosKey];
                                cell.appendChild(doc.createTextNode(ovPos));
                                cell.className = 'center-cell';
                            } else if (pData[1] === 'rank_vs_adp' && FPW.hideADP.indexOf(FPW.pos) !== -1 && FPW.sport === 'NFL') {
                                //Hide cell if ADP is excluded
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(''));
                                cell.className = 'hide';
                            } else if (pData[1] === 'rank_vs_ecr' && !FPW.showVsECR && ['NFL', 'MLB', 'NBA'].includes(FPW.sport)) {
                                //Hide cell if showVsECR is false
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(''));
                                cell.className = 'hide';
                            } else {
                                var cellVal = (pData[1].indexOf('vs') !== -1) ? (player[pData[1]] <= 0 ? '' : '+') + player[pData[1]] : player[pData[1]];
                                if (!cellVal || cellVal === 'undefined') {
                                    cellVal = '';
                                }
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(cellVal));
                                cell.className = 'center-cell';
                            }
                        });
                    } else if (FPW.wtype == 'MOCK') {
                        // MOCK DRAFT
                        tbRow = tbody.insertRow(-1);
                        z++;
                        FPW.columns.forEach(function(pData, y) {
                            var cell;
                            if (y === 2) {
                                cell = tbRow.insertCell(y);
                                cell.className = 'fp-player-name-cell';
                                var a = FPW.create('a', false, false, cell);
                                a.href = (FPW.yahoo) ? 'https://sports.yahoo.com/' + FPW.sport.toLowerCase() + '/players/' + player.player_yahoo_id : player[pData[1].split(':')[1]];
                                if (FPW.affiliateCode !== '' && !FPW.yahoo) {
                                    a.href += '?partner=' + FPW.affiliateCode;
                                }
                                a.target = '_blank';
                                a.innerHTML = player[pData[1].split(':')[0]];

                                a = FPW.create('a', false, 'fp-player-link fp-id-' + player.player_id, cell);
                                a.href = '#';
                                a.setAttribute('fp-player-name', player.player_name);
                            } else if (pData[0] === 'Notes' && FPW.notes === 'true') {
                                cell = tbRow.insertCell(y);
                                if (player[pData[1]] !== '') {
                                    cell.className = 'fpw-note-cell';
                                    cell.innerHTML = player[pData[1]];

                                    var note = FPW.create('div', false, 'fpw-notes', cell);
                                    note.innerHTML = player[pData[1]];
                                }
                            } else if (pData[0] === 'TAG') {
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(player.tag.charAt(0).toUpperCase() + player.tag.slice(1)));
                                cell.className = 'center-cell tag-cell';
                                if (player.tag != '') {
                                    cell.className += ' ' + player.tag;
                                }
                            } else {
                                var cellVal = (pData[1].indexOf('vs') !== -1) ? (player[pData[1]] <= 0 ? '' : '+') + player[pData[1]] : player[pData[1]];
                                cell = tbRow.insertCell(y);
                                cell.appendChild(doc.createTextNode(cellVal));
                                if (pData[0] === 'Pick' || pData[0] === 'Pos') {
                                    cell.className = 'center-cell';
                                }
                            }
                        });
                    }
                }
            });
        } else {
            for (const team_id in data.teams) {
                const team = data.teams[team_id];

                let tbRow = tbody.insertRow(-1);
                for (let [i, column] of FPW.columnsByPosition[FPW.pos].entries()) {
                    let cell = tbRow.insertCell(i);

                    let emptyCellValue = 'BYE';
                    let apiPropertyName = column[1];
                    if (apiPropertyName.includes('opp_rank') || apiPropertyName.includes('diff')) {
                        emptyCellValue = '-';
                    }

                    const cellValue = apiPropertyName.includes('_diff') && team[apiPropertyName] > 0 ? `+${team[apiPropertyName]}` : team[apiPropertyName];
                    cell.className = column[2] || '';
                    cell.appendChild(doc.createTextNode(cellValue || emptyCellValue));
                }
            }
        }
        var pub = (FPW.wtype.indexOf('ST') !== -1) ? '' : (data.published) ? FPW.getPubDate(data.published, 'long') : data.last_updated;
        return [table, pub, exists];
    },
    'buildFPBlog': function(data) { //Build rankings div after widgetCallback if widget in blog style.
        var doc = document;
        var wBlog;
        if (doc.getElementById('fp-pos-blog')) {
            wBlog = doc.getElementById('fp-pos-blog');
            wBlog.innerHTML = '';
        } else {
            wBlog = FPW.create('div', 'fp-pos-blog');
        }

        var z = 0;
        var tier = 0;
        var p;

        data.players.forEach(function(player) {
            if (FPW.rankLimit === -1 || z < FPW.rankLimit) {
                if (typeof player.tier !== 'undefined' && player.tier !== tier && player.tier && player.tier.length !== 0) {
                    p = FPW.create('p', false, 'fp-widget-tier', wBlog);
                    p.appendChild(document.createTextNode('Tier ' + player.tier));
                    tier = player.tier;
                }
                if (['ALL', 'FLX', 'OP', 'RK', 'IDP', 'DL', 'DB', 'LB', 'H', 'P', 'G', 'F', 'OT', 'OG', 'IOL', 'OL', 'IDL', 'EDGE'].indexOf(FPW.pos) !== -1 ||
                    FPW.wtype == 'MOCK' ||
                    player[FPW.sitePositions].split(',').indexOf(FPW.pos) !== -1 ||
                    (FPW.pos === 'OF' && (player[FPW.sitePositions].split(',').indexOf('CF') !== -1 ||
                            player[FPW.sitePositions].split(',').indexOf('LF') !== -1 ||
                            player[FPW.sitePositions].split(',').indexOf('RF') !== -1 ||
                            player[FPW.sitePositions].split(',').indexOf('OF') !== -1)
                    )
                ) {
                    z++;
                    p = FPW.create('p', false, 'fpw-player-p', wBlog);
                    var div = FPW.create('div', false, 'fpw-img-cont', p)
                    if (FPW.sport + FPW.wtype != 'NFLPROSPECT' && FPW.wtype != 'MOCK') {
                        var pIMG = FPW.create('img', false, 'fpw-player-img', div);
                        pIMG.src = (player.player_square_image_url === '') ? '//images.fantasypros.com/images/players/' + FPW.sport.toLowerCase() + '/missing/headshot/70x70.png' : player.player_square_image_url;
                    }
                    var span = FPW.create('span', false, false, p);
                    if (FPW.wtype == 'MOCK') {
                        span.innerHTML = '<b>' + player.pick_label + '.  ' + player.pick_team_label + '</b>:  ';
                    } else {
                        span.innerHTML = '<b>' + z + '</b>. ';
                    }

                    var a = FPW.create('a', false, false, span);
                    a.href = player.player_page_url;
                    a.target = '_blank';
                    a.innerHTML = '<b>' + player.player_name + '</b>';

                    span.innerHTML = span.innerHTML + '<span class="player-team">' + eval((FPW.multiPos.indexOf(FPW.pos) === -1 ? FPW.blogFormat : FPW.multiBlogFormat)).replace('null', '') + '</span>';

                    a = FPW.create('a', false, 'fp-player-link fp-id-' + player.player_id, span);
                    a.href = '#';
                    a.setAttribute('fp-player-name', player.player_name);

                    if (FPW.tags === 'true') {
                        span.innerHTML = span.innerHTML + '<span class="fpw-player-tag ' + player.tag + '">' + player.tag.charAt(0).toUpperCase() + player.tag.slice(1) + '</span>';
                    }

                    if (FPW.notes === 'true') {
                        p.innerHTML = p.innerHTML + '<div>' + player.notes + '</div>';
                    }

                    p.innerHTML = p.innerHTML + '<div style="clear:both;"></div>';
                }
            }
        });

        return [wBlog, FPW.getPubDate(data.published)];
    },
    'buildFPCheatsheet': function(data) { //Build rankings div after widgetCallback if widget in cheatsheet style.
        var doc = document;

        data.players.forEach(function(player) {
            if (typeof FPW.posDiv[data.position_id] === 'undefined') {
                FPW.posDiv[data.position_id] = [];
            }
            FPW.posDiv[data.position_id].push(player);
        });

        var div, rank, playerDiv, span;
        rank = 1;
        div = doc.getElementById('fpw-cs-pos-div-' + data.position_id);
        div.innerHTML = '<h4>' + data.position_id + '</h4>';
        FPW.posDiv[data.position_id].forEach(function(player) {
            if (FPW.rankLimit === -1 || rank <= FPW.rankLimit) {
                playerDiv = FPW.create('div', false, 'fpw-cheatsheet-playerDiv', div);
                span = FPW.create('span', false, 'fpw-cheatsheet-rank', playerDiv);
                span.innerHTML = rank + '.';

                var a = FPW.create('a', false, 'fpw-cheatsheet-playerA', playerDiv);
                a.href = player.player_page_url;
                a.target = '_blank';
                a.innerHTML = player.player_name + '&nbsp;';

                span = FPW.create('span', false, 'player-team', playerDiv);
                span.innerHTML += '(' + player.player_team_id + ')';

                a = FPW.create('a', false, 'fp-player-link fp-id-' + player.player_id, playerDiv);
                a.href = '#';
                a.setAttribute('fp-player-name', player.player_name);

                if (data.position_id === 'ALL') {
                    span = FPW.create('span', false, 'fpw-cheatsheet-pos', playerDiv);
                    if (FPW.sport === 'NBA') {
                        span.innerHTML += player.player_sd_positions;
                    } else {
                        span.innerHTML += player.player_positions;
                    }

                }

                rank++;
            }
        });

        if (FPW.ecrOnly) {
            doc.getElementById('fp-widget-pubDate').innerHTML = '(Updated ' + FPW.getPubDate(data.published) + ')';
        } else {
            const params = {
                'sport': FPW.sport,
                'year': FPW.year,
                'week': FPW.week,
                'id': FPW.expert,
                'position': FPW.pos,
                'type': FPW.wtype,
                'notes': FPW.notes,
                'scoring': FPW.scr,
                'export': 'xls'
            }
            doc.getElementById('fp-widget-pubDate').innerHTML = `(Updated ${FPW.getPubDate(data.published)}) <a href="${FPW.buildURL('/api/v1/expert-rankings.php', params)}" rel="nofollow"><img style="vertical-align:middle;" width="16px;" src="https://images.fantasypros.com/images/icons/export.png"/></a>`;
        }
    },
    'pprScoringOptions': function() { //NFL scoring choices, each gated by its own position bucket
        // STD rides on the categories bucket, which is empty when the embed holds only
        // PPR or only HALF ranks. Yahoo experts publish no STD ranks at all.
        var options = [
            {value: 'PPR', positions: FPW.ppr_pos},
            {value: 'HALF', positions: FPW.half_pos}
        ];
        if (!FPW.yahoo) {
            options.push({value: 'STD', positions: FPW.cats_pos});
        }
        return options;
    },
    'availablePPRScorings': function() { //NFL scoring choices the current view can really offer
        return FPW.pprScoringOptions().filter(function(option) {
            return FPW.scoringFits(option.positions);
        });
    },
    'createPPRradio': function() { //Create radio select for STD vs. PPR scoring. (NFL ONLY)
        var doc = document;
        var wEldgSelect = FPW.create('div', 'fp-widget-ppr-select', 'pull-left select-options', doc.getElementById('fp-widget-subDiv'));
        var span = FPW.create('span', false, 'select-wrap', wEldgSelect);
        var wSelectP = FPW.create('label', false, 'pull-left', wEldgSelect);
        wSelectP.style.margin = '3px 5px 0 0px';
        wSelectP.innerHTML = 'Scoring';

        var array;
        if (FPW.yahoo) {
            array = ['HALF', 'PPR'];
            if (FPW.half_pos.length === 0) {
                array = ['PPR'];
            } else if (FPW.ppr_pos.length === 0) {
                array = ['HALF'];
            }
        } else {
            array = ['STD', 'PPR', 'HALF'];
        }

        var fpSelectList = FPW.create('select', 'fp-widget-pos-select', false, span);

        for (var i = 0; i < array.length; i++) {
            var option = FPW.create('option', false, false, fpSelectList);
            option.value = array[i];
            option.text = array[i];
            option.className = array[i] + '-select';
            if (array[i] === FPW.scr) {
                option.selected = 'selected';
            }
        }

        fpSelectList.onchange = function() {
            FPW.scr = this.options[this.selectedIndex].value;
            FPW.getNewRank();
        };

        // One choice is no choice: hide the whole control when the current view has a
        // single scoring, rather than render a select the reader cannot change.
        if (FPW.availablePPRScorings().length > 1 && FPW.output !== 'HTML' && FPW.positions[0] !== '') {
            wEldgSelect.style.display = 'initial';
            if (!FPW.scoringFits(FPW.ppr_pos)) {
                doc.querySelector('.PPR-select').style.display = 'none';
                doc.querySelector('.PPR-select').setAttribute('hidden', '');
                doc.querySelector('.PPR-select').setAttribute('disabled', '');
            }

            if (!FPW.scoringFits(FPW.cats_pos) && doc.querySelector('.STD-select')) {
                doc.querySelector('.STD-select').style.display = 'none';
                doc.querySelector('.STD-select').setAttribute('hidden', '');
                doc.querySelector('.STD-select').setAttribute('disabled', '');
            }

            if (!FPW.scoringFits(FPW.half_pos)) {
                doc.querySelector('.HALF-select').style.display = 'none';
                doc.querySelector('.HALF-select').setAttribute('hidden', '');
                doc.querySelector('.HALF-select').setAttribute('disabled', '');
            }
        } else {
            wEldgSelect.style.display = 'none';
        }
    },
    'scoringHeaderLabel': function() { //Name the scoring in the header when the embed uses exactly one
        // A populated categories bucket means the embed is not single-scoring.
        if (FPW.cats_pos && FPW.cats_pos[0] !== '') {
            return '';
        }
        var buckets = [
            {label: ' Points', positions: FPW.pts_pos},
            {label: ' High Score', positions: FPW.highscore_pos},
            {label: ' 9-Cat', positions: FPW.nine_cat_pos}
        ];
        var used = buckets.filter(function(bucket) {
            return bucket.positions && bucket.positions.length > 0 && bucket.positions[0] !== '';
        });
        return used.length === 1 ? used[0].label : '';
    },
    'scoringOptions': function() { //NBA scoring choices, each gated by its own position bucket
        // `value` is what the API receives as &scoring=. STD rides on the categories
        // bucket, so a High Score-only position such as FC cannot offer it.
        return [
            {value: 'STD', text: 'STD', positions: FPW.cats_pos},
            {value: 'PTS', text: 'PTS', positions: FPW.pts_pos},
            {value: 'HIGHSCORE', text: 'High Score', positions: FPW.highscore_pos},
            {value: '9CAT', text: '9-Cat', positions: FPW.nine_cat_pos}
        ];
    },
    'scoringFits': function(positions) { //Does this bucket cover what the widget is showing?
        // A cheatsheet renders every position at once, so it asks whether the bucket
        // exists at all rather than whether it covers one position.
        if (!positions || positions.length === 0 || positions[0] === '') {
            return false;
        }
        return FPW.format === 'cheatsheet' || positions.indexOf(FPW.pos) !== -1;
    },
    'availableScorings': function() { //Scoring choices the current view can really offer
        return FPW.scoringOptions().filter(function(option) {
            return FPW.scoringFits(option.positions);
        });
    },
    'createPTSradio': function() { //Create the scoring select. (NBA ONLY)
        var doc = document;
        var wEldgSelect = FPW.create('div', 'fp-widget-pts-select', 'pull-left select-options', doc.getElementById('fp-widget-subDiv'));
        var span = FPW.create('span', false, 'select-wrap', wEldgSelect);
        var wSelectP = FPW.create('label', false, 'pull-left', wEldgSelect);
        wSelectP.style.margin = '3px 5px 0 0px';
        wSelectP.innerHTML = 'Scoring';

        var array = FPW.scoringOptions();

        var fpSelectList = FPW.create('select', 'fp-widget-pos-select', false, span);

        for (var i = 0; i < array.length; i++) {
            var option = FPW.create('option', false, false, fpSelectList);
            option.value = array[i].value;
            option.text = array[i].text;
            option.className = array[i].value + '-select';
            // Selected by attribute, never by class: '9CAT-select' is a legal class
            // name but '.9CAT-select' is not a legal CSS selector.
            option.setAttribute('data-scoring', array[i].value);
        }

        fpSelectList.onchange = function() {
            FPW.scr = this.options[this.selectedIndex].value;
            FPW.getNewRank();
        };

        // One choice is no choice: the header already names the scoring, so a select
        // with a single option is noise.
        if (FPW.availableScorings().length > 1 && FPW.output !== 'HTML' && FPW.positions[0] !== '') {
            wEldgSelect.style.display = 'initial';
            FPW.toggleScoringOptions(fpSelectList);
        } else {
            wEldgSelect.style.display = 'none';
        }
    },
    'toggleScoringOptions': function(selectEl) { //Hide scoring options the current position has no rankings for
        var array = FPW.scoringOptions();
        for (var i = 0; i < array.length; i++) {
            var option = selectEl.querySelector('[data-scoring="' + array[i].value + '"]');
            if (option) {
                option.style.display = FPW.scoringFits(array[i].positions) ? 'initial' : 'none';
            }
        }
        FPW.syncScoringForPosition(selectEl);
    },
    'currentScoringOptions': function() { //The scoring family this sport's select offers
        // Mirrors the createPPRradio/createPTSradio split. NFL and NBA scoring values do
        // not overlap, so reading the NBA family for an NFL embed matches nothing and
        // sends every position change to STD. Sports with no select normalize nothing.
        if (FPW.sport === 'NFL' || FPW.sport === 'NCAAF') {
            return FPW.pprScoringOptions();
        }
        if (FPW.sport === 'NBA') {
            return FPW.scoringOptions();
        }
        return [];
    },
    'syncScoringForPosition': function(selectEl) { //Move off a scoring the current position has no rankings for
        // Must run before getNewRank(), or the request carries the previous position's
        // scoring and the table comes back empty.
        var array = FPW.currentScoringOptions();
        var current = array.filter(function(option) {
            return option.value === FPW.scr;
        })[0];

        if (current && FPW.scoringFits(current.positions)) {
            return;
        }

        var replacement = array.filter(function(option) {
            return FPW.scoringFits(option.positions);
        })[0];
        if (!replacement) {
            return;
        }

        FPW.scr = replacement.value;

        var el = selectEl || document.getElementById('fp-widget-pos-select');
        if (el) {
            el.value = FPW.scr;
        }
    },
    'createFPTabs': function() { //Create position tabs if overall rankings.
        var tabCont = FPW.create('div', false, 'pills-wrap feature-bg', document.getElementById('fp-widget-body'));
        var tabUL = FPW.create('ul', 'fp-widget-ul', 'pills', tabCont);

        if (FPW.wtype == 'MOCK') {
            var roundLabel = FPW.create('li', 'fp-widget-round-label');
            roundLabel.innerHTML = 'Round: ';
            tabUL.appendChild(roundLabel);
        }

        var posLI, posA;
        FPW.tabPositions.forEach(function(pos) {
            posLI = FPW.create('li');
            posA = FPW.create('a');
            posLI.onclick = FPW.tabToggle;

            if (pos === 'ALL') {
                posA.innerHTML = 'Overall';
            } else if (pos === 'FLX') {
                posA.innerHTML = 'Flex';
            } else if (pos === 'OP') {
                posA.innerHTML = 'Superflex';
            } else {
                posA.innerHTML = pos;
            }

            if (FPW.pos === pos) {
                posLI.className = 'active';
            }

            if (pos.indexOf('PPR') === -1) {
                tabUL.appendChild(posLI).appendChild(posA);
            }
        });
    },
    'createSiteEldg': function() { //Create select element for site specific position eligibility. (MLB ONLY)
        var wEldgSelect = FPW.create('div', 'fp-widget-site-select', false, document.getElementById('fp-widget-subDiv'));
        var span = FPW.create('span', false, 'select-wrap', wEldgSelect);
        var wSelectP = FPW.create('label', false, 'pull-left', wEldgSelect);
        wSelectP.style.margin = '3px 5px 0 0px';
        wSelectP.innerHTML = 'Position Eligibility ';

        var array = ['Combined', 'Yahoo', 'ESPN', 'CBS'];

        var fpSelectList = FPW.create('select', 'fp-widget-elig-select', false, span);

        var site;

        for (var i = 0; i < array.length; i++) {
            var option = FPW.create('option', false, false, fpSelectList);
            switch (array[i]) {
                case 'Combined':
                    site = 'player_positions';
                    break;
                case 'Yahoo':
                    site = 'player_yahoo_positions';
                    break;
                case 'ESPN':
                    site = 'player_espn_positions';
                    break;
                case 'CBS':
                    site = 'player_cbs_positions';
                    break;
                default:
                    site = 'player_positions';
            }
            option.value = site;
            option.text = array[i];
        }

        fpSelectList.onchange = function() {
            FPW.sitePositions = this.options[this.selectedIndex].value;
            if (FPW.output === 'blog') {
                FPW.buildFPBlog(FPW.callbackData);
            } else {
                FPW.buildFPTable(FPW.callbackData);
            }

        };
    },
    'getNewRank': function() { //Make JSONP call to get fresh data with new selected position.
        var doc = document;

        if (FPW.format === 'cheatsheet') {
            let posScript;

            FPW.posDiv = {};

            FPW.positions.forEach(function(pos) {
                posScript = FPW.create('script', 'fpw-rankings-call-' + pos);
                const params = {
                    sport: FPW.sport,
                    year: FPW.year,
                    week: FPW.week,
                    id: FPW.expert,
                    position: pos,
                    type: FPW.wtype,
                    scoring: FPW.scr,
                    callback: 'FPW.rankingsCB'
                }
                posScript.src = FPW.buildURL('/api/v1/expert-rankings.php', params);

                if (doc.head.contains(doc.getElementById('fpw-rankings-call-' + pos))) {
                    doc.getElementsByTagName('head')[0].replaceChild(posScript, doc.getElementById('fpw-rankings-call-' + pos));
                } else {
                    doc.getElementsByTagName('head')[0].appendChild(posScript);
                }
            });
        } else {
            let tabData = FPW.create('script', 'fpw-rankings-call');

            let pos;
            switch (FPW.pos) {
                case 'Flex':
                    pos = 'FLX';
                    break;
                case 'Superflex':
                    pos = 'OP';
                    break;
                default:
                    pos = FPW.pos;
            }

            tabData.src = FPW.buildRankingsURL({ 'position': pos })
            doc.getElementsByTagName('head')[0].replaceChild(tabData, doc.getElementById('fpw-rankings-call'));
        }
    },
    'tabToggle': function() { //Toggle current tab and call getNewRank to get fresh rankings data.
        var doc = document;
        var self = this;
        var selPos = self.childNodes[0].innerHTML === 'Overall' ? 'ALL' : self.childNodes[0].innerHTML;
        selPos = selPos === 'Flex' ? 'FLX' : selPos;
        selPos = selPos === 'Superflex' ? 'OP' : selPos;

        FPW.pos = selPos;
        FPW.syncScoringForPosition();
        FPW.getNewRank();

        var ul = self.parentNode.childNodes;

        for (var i = 0; i < ul.length; i++) {
            if (ul[i] === self) {
                ul[i].className = 'active';
            } else {
                ul[i].className = '';
            }
        }

        if (doc.getElementById('fp-widget-ppr-select')) {
            if (FPW.availablePPRScorings().length > 1 && FPW.positions[0] !== '') {
                doc.getElementById('fp-widget-ppr-select').style.display = 'initial';

                if (doc.querySelector('.PPR-select')) {
                    if (!FPW.scoringFits(FPW.ppr_pos)) {
                        doc.querySelector('.PPR-select').style.display = 'none';
                        doc.querySelector('.PPR-select').setAttribute('hidden', '');
                        doc.querySelector('.PPR-select').setAttribute('disabled', '');
                    } else {
                        doc.querySelector('.PPR-select').style.display = 'initial';
                        doc.querySelector('.PPR-select').removeAttribute('hidden');
                        doc.querySelector('.PPR-select').removeAttribute('disabled');
                    }
                }

                if (doc.querySelector('.STD-select')) {
                    if (!FPW.scoringFits(FPW.cats_pos)) {
                        doc.querySelector('.STD-select').style.display = 'none';
                        doc.querySelector('.STD-select').setAttribute('hidden', '');
                        doc.querySelector('.STD-select').setAttribute('disabled', '');
                    } else {
                        doc.querySelector('.STD-select').style.display = 'initial';
                        doc.querySelector('.STD-select').removeAttribute('hidden');
                        doc.querySelector('.STD-select').removeAttribute('disabled');
                    }
                }

                if (doc.querySelector('.HALF-select')) {
                    if (!FPW.scoringFits(FPW.half_pos)) {
                        doc.querySelector('.HALF-select').style.display = 'none';
                        doc.querySelector('.HALF-select').setAttribute('hidden', '');
                        doc.querySelector('.HALF-select').setAttribute('disabled', '');
                    } else {
                        doc.querySelector('.HALF-select').style.display = 'initial';
                        doc.querySelector('.HALF-select').removeAttribute('hidden');
                        doc.querySelector('.HALF-select').removeAttribute('disabled');
                    }
                }
            } else {
                doc.getElementById('fp-widget-ppr-select').style.display = 'none';
            }
        }
        if (doc.getElementById('fp-widget-pts-select')) {
            if (FPW.availableScorings().length > 1 && FPW.positions[0] !== '') {
                doc.getElementById('fp-widget-pts-select').style.display = 'initial';
                var scoringSelect = doc.getElementById('fp-widget-pos-select');
                if (scoringSelect) {
                    FPW.toggleScoringOptions(scoringSelect);
                }
            } else {
                doc.getElementById('fp-widget-pts-select').style.display = 'none';
            }
        }
    },
    'getPubDate': function(data, length) { // Format published date
        length = length || false;
        const a = data.split(/[^0-9]/);
        const d = new Date(a[0], a[1] - 1, a[2]);
        let pubDate = (d.getMonth() + 1) + '/' + d.getDate();
        if (length !== 'short') {
            pubDate += '/' + d.getFullYear().toString().slice(-2);
        }

        return pubDate;
    },
    'yahooTeam': function(team_id) {
        if (team_id === 'gb') {
            team_id = 'gnb';
        } else if (team_id === 'kc') {
            team_id = 'kan';
        } else if (team_id === 'ne') {
            team_id = 'nwe';
        } else if (team_id === 'no') {
            team_id = 'nor';
        } else if (team_id === 'sf') {
            team_id = 'sfo';
        } else if (team_id === 'tb') {
            team_id = 'tam';
        }

        return team_id;
    },
    'removeColumn': function(index) {
        FPW.columns.splice(index, 1);
    },
    'addColumn': function(index, column) {
        FPW.columns.splice(index, 0, column);
    },
    'getOrdinal': function(n) { //Get ordinal for a number. Used for published date.
        var s = ['th', 'st', 'nd', 'rd'];
        var v = n % 100;
        return n + (s[(v - 20) % 10] || s[v] || s[0]);
    },
    'create': function(element, id, className, parent) { // Create element, assign id, and append to parent
        var e = document.createElement(element);
        if (typeof className !== 'undefined' && className !== false) {
            e.className = className;
        }
        if (typeof id !== 'undefined' && id !== false) {
            e.id = id;
        }
        if (typeof parent !== 'undefined') {
            parent.appendChild(e);
        }

        return e;
    },
    'buildRankingsURL': function(baseParametersToOverride = {}) {
        let params = {
            'callback': 'FPW.rankingsCB',
            'position': FPW.pos,
            'sport': FPW.sport,
            'year': FPW.year,
            'week': FPW.week
        }

        params = { ...params, ...baseParametersToOverride };

        let endpoint;

        if (FPW.wtype.includes('ST') && FPW.wtype !== 'BEST' || FPW.wtype === 'WW') {
            params.experts = 'show';
            params.id = FPW.expert;
            params.type = FPW.convertWidgetTypeToParamType();
            params.scoring = FPW.scr;
            params.filters = FPW.filters;
            params.widget = 'ST';

            endpoint = '/api/v1/consensus-rankings.php';
        } else if (FPW.wtype === 'POWER') {
            params.filters = FPW.filters || FPW.expert;

            endpoint = '/api/v1/power-rankings.php';
        } else {
            params.id = FPW.expert;
            params.scoring = FPW.scr;
            params.type = FPW.wtype;

            if (FPW.adp) {
                params.adp = FPW.adp;
            }
            endpoint = '/api/v1/expert-rankings.php';
        }

        return FPW.buildURL(endpoint, params);
    },
    'buildURL': function(pathWithoutHost, parameters) {
        let root_host = 'partners.fantasypros.com'
        const host_split = location.host.split('.');
        if (host_split[host_split.length - 1] === 'test') {
            root_host = 'local.fp.test';
        } else if (/ep3-\w+\.fantasypros\.com/.test(location.host)) {
            root_host = location.host.match(/ep3-(\w+)\.fantasypros\.com/)[1] + '.fantasypros.com';
        }

        let cache_query_string = '';
        if (['ep.fantasypros.com', 'epdev.fantasypros.com', 'ep3.fantasypros.com', 'ep.fp.test'].includes(location.host)) {
            cache_query_string = '&host=ta&ts=' + Math.round(new Date().getTime() / 1000);
        } else if ([['theathletic.com', 'www.theathletic.com', 'theathletic.com']].includes(location.host)) {
            cache_query_string = '&host=ta';
        }

        return `//${root_host}${pathWithoutHost}?${new URLSearchParams(parameters)}${cache_query_string}`;
    },
    'convertWidgetTypeToParamType': function() {
        switch (FPW.wtype) {
            case 'STROS':
                return 'ROS';
            case 'STK':
                return 'DK';
            case 'STPROSPECT':
                return 'PROSPECT';
            case 'STBEST':
                return 'BEST';
            case 'STDEVY':
                return 'DEVY';
            case 'STROOKIES':
                return 'ROOKIES';
            case 'STWW':
                return 'WW';
            default:
                return FPW.wtype;
        }
    },
    'CSS': function(height, width, tHead_color, tHead_font, t_alt_row, link_color, pill_color) { //Create CSS Style tag with variables.
        var doc = document;

        var columnWidth = 50;

        if (doc.getElementById('fp-widget').offsetWidth >= 600 && doc.getElementById('fp-widget').offsetWidth < 800) {
            columnWidth = 33.33;
        } else if (doc.getElementById('fp-widget').offsetWidth >= 800) {
            columnWidth = 25;
        }

        var fpStyles = FPW.create('style', false, false, doc.getElementById('fp-widget'));

        var styles = '@import url(//fonts.googleapis.com/css?family=Poppins:100,200,400,600,700,800);\n';
        // styles += '@import url(//ep.fantasypros.com/css/fp_styles.css);\n';
        if (parent !== window) {
            styles += 'body{margin:0;}';
        }
        styles += '#fp-widget,#fp-widget div{box-sizing:border-box;font-weight:400;font-family:\'Open Sans\',HelveticaNeue,"Helvetica Neue",Helvetica,Arial,sans-serif;color:#212121}#fp-widget .pull-left{float:left}#fp-widget .pull-right{float:right}#fp-widget h1,#fp-widget h2,#fp-widget h3,#fp-widget h4,#fp-widget h5,#fp-widget h6{font-family:Poppins,sans-serif;margin-top:0;margin-bottom:1rem;font-weight:300}#fp-widget h4{line-height:1.3;font-weight:700}#fp-widget .btn-group:after,#fp-widget .clearfix,#fp-widget .clearfix:after,#fp-widget .container:after,#fp-widget .mega-dropdown:after{clear:both}#fp-widget .pills-wrap{font-family:Poppins,sans-serif;font-weight:400;padding:10px 0}#fp-widget .feature-bg{padding:10px 20px;background-color:#f5f5f5;border-top:solid 1px #d3d3d3;border-bottom:solid 1px #d3d3d3}#fp-widget ul{list-style:circle inside}#fp-widget ul.pills{margin:0;padding:0;line-height:14px}@media (min-width:550px){#fp-widget div.pills-wrap ul.pills>li{width:auto;margin-bottom:0}}#fp-widget ul.pills li{display:inline-block;margin:0 1px;color:#999}#fp-widget ul.pills li>a{display:block;color:#434343;padding:6px 12px;font-size:13px;border-radius:14px;cursor:pointer;}#fp-widget a{background-color:transparent;text-decoration:none}#fp-widget img,#fp-widget legend{border:0}#fp-widget label,#fp-widget legend{display:block;margin-bottom:.5rem}#fp-widget .select-wrap{position:relative;height:30px;display:inline-block;background:url(https://images.fantasypros.com/images/icons/gray_caret.png) right 5px bottom 4px no-repeat #fff;background-size:18px 22px}#fp-widget .select-wrap select,#fp-widget .select-wrap select:focus{border:1px solid #AAA;border-radius:0;width:200px;font-size:12px;color:#666;padding:6px 22px 6px 12px;line-height:16px;height:auto;-webkit-appearance:none;-moz-appearance:none;-webkit-border-radius:0;background:0 0}#fp-widget input[type=email],#fp-widget input[type=number],#fp-widget input[type=search],#fp-widget input[type=text],#fp-widget input[type=tel],#fp-widget input[type=url],#fp-widget input[type=password],#fp-widget select,#fp-widget textarea{padding:5px 10px;height:36px;background-color:#fff;border:1px solid #D1D1D1;border-radius:4px;box-shadow:none;box-sizing:border-box}#fp-widget button,#fp-widget select{text-transform:none}#fp-widget button,#fp-widget input,#fp-widget optgroup,#fp-widget select,#fp-widget textarea{color:inherit;font:inherit;margin:0}#fp-widget table{border-collapse:collapse;border-spacing:0}#fp-widget .table.table-full{width:100%}#fp-widget .table.table-bordered td,#fp-widget .table.table-bordered th{border:1px solid #eaeaea}#fp-widget .table.table-striped tr td{background-color:#ffffff}#fp-widget .table.table-striped tr:nth-child(2n-1) td{background-color:#f5f5f5}#fp-widget .table th{font-weight:700;text-align:center;text-transform:uppercase;font-size:12px}#fp-widget .table th,.table td{font-size:12px;padding: 8px 5px;line-height: 1.6;border:none}#fp-widget .table td{font-weight:400;text-align:left}';
        styles += '#fp-widget th.sort-header::-moz-selection{background:0 0}#fp-widget th.sort-header::selection{background:0 0}#fp-widget th.sort-header{cursor:pointer;position:relative;}#fp-widget th.sort-header::-moz-selection,#fp-widget th.sort-header::selection{background:0 0}#fp-widget table th.sort-header:after{content: "";bottom: 5px;left: 50%;position: absolute;border-width: 4px 4px 0;border-style: solid;border-color: #404040 transparent;visibility: hidden;opacity: .9;transform: translateX(-50%);}#fp-widget table th.sort-header:hover:after{visibility:visible}#fp-widget table th.sort-down:after,#fp-widget table th.sort-down:hover:after,#fp-widget table th.sort-up:after{visibility:visible;opacity:.4;}#fp-widget table th.sort-up:after{border-width: 0 4px 4px;top: 5px;bottom: auto;position:absolute;}';
        styles += '.pills-wrap.feature-bg { margin: 0; padding: 8px 10px; }';
        styles += '#fp-widget { height: ' + height + '; width: ' + width + '; }';
        styles += '#fp-widget a { color: ' + link_color + '; border: none;}';
        styles += '#fp-widget .fpw-player-p a b { color: ' + link_color + '; border: none;}';
        styles += '#fp-widget ul.pills li > a:hover { color: #212121; }';
        styles += '#fp-widget ul.pills li.active a, ul.pills li.active > a:hover { color: #fafafa; }';
        styles += '#fp-widget ul.pills li.active a, ul.pills li.active > a:hover { background-color: ' + pill_color + '; }';
        styles += '#fp-widget .feature-bg.feature-stretch { background-image: none; }';
        styles += '#fp-widget .feature-bg { border-top: none; }'
        styles += '#fp-widget .expert-name { text-overflow: ellipsis; width: 100%; display: inline-block; overflow: hidden; }';
        styles += '#fp-widget-subDiv { padding: 8px 5px; background-color: #fafafa }';
        styles += '#fp-widget .select-options { margin-right: 15px; }';
        styles += '#fp-widget-header { border-bottom: 1px solid #d3d3d3; padding-bottom: 5px; }';
        if (FPW.yahoo) {
            styles += '#fp-widget .table th { font-size: 10px; }';
        }
        styles += '#fpPosTable thead th{ background-color: ' + tHead_color + '; color: ' + tHead_font + '; }';
        if (FPW.wtype !== 'ST' && FPW.wtype !== 'STK') {
            styles += '#fpPosTable thead tr { line-height: 8px; }';
        }
        if (FPW.wtype == 'MOCK') {
            styles += '#fp-widget ul.pills li#fp-widget-round-label { color: #323232; margin-right: 10px; font-weight: 600;}';
        }
        styles += '#fpPosTable thead .notes-col, #fpPosTable thead .name-col { text-align: left; }';
        styles += '#fp-widget .table.table-striped tr:nth-child(2n-1) td { background-color: ' + t_alt_row + '; }';
        styles += '#fp-widget #fp-widget-content, #fp-widget-body { height: inherit; width: inherit; }';
        styles += '#fp-widget #fp-widget-pos-select { width: 70px; }';
        styles += '#fp-widget #fp-widget-elig-select { width: 100px; }';
        styles += '#fp-widget-header h4 { margin-bottom: 0; }';
        styles += '#fp-widget-header a { font-size: 12px; }';
        styles += '#fp-widget .notes-col { width: 35%; }';
        styles += '#fp-widget .tag-col { min-width: 40px; }';
        styles += '#fp-widget .school-col { min-width: 80px; }';
        styles += '#fp-widget .table .center-cell { text-align: center; }';
        styles += '#fp-widget .table .hide { display: none; }';
        styles += '#fp-widget .table td.fp-player-name-cell { text-align: left; white-space: nowrap; }';
        if (!FPW.theAthletic || window.innerWidth >= 600) {
            styles += '#fp-widget .matchup-col { min-width: 60px; }';
            styles += '#fp-widget .small-col { min-width: 44px; }';
            styles += '#fp-widget .name-col { min-width: 200px; }';
        } else if (FPW.theAthletic && window.innerWidth < 600) {
            styles += '#fp-widget .player-table th, #fp-widget .player-table td { font-size: 60% }';
        }
        if (FPW.theAthletic) {
            styles += '#fp-widget .table { margin-bottom: 5rem; }';
        }
        styles += '#fp-widget .short-name-col { min-width: 160px; }';
        styles += '#fp-widget .tag-cell, .fpw-player-tag { color: #4E99EF; }';
        styles += '#fp-widget table.player-table td.tag-cell.sleeper, .fpw-player-tag.sleeper { background-color: #ecfe99; padding: 5px; border: 1px solid #e7e7e7; color: #878787; }';
        styles += '#fp-widget table.player-table td.tag-cell.target, .fpw-player-tag.target { background-color: #bffebf; padding: 5px; border: 1px solid #e7e7e7; color: #878787; }';
        styles += '#fp-widget table.player-table td.tag-cell.avoid, .fpw-player-tag.avoid { background-color: #fed2d3; padding: 5px; border: 1px solid #e7e7e7; color: #878787; }';
        styles += '#fp-widget .fpw-player-tag { font-size: 12px; margin-left: 5px; }';
        styles += '.fpw-note-cell:before { content: \'+ \'; font-weight: bold; font-size: 14px; }';
        styles += '.fpw-note-cell { text-overflow: ellipsis; width: 100%; white-space: nowrap; overflow: hidden; cursor: default; }';
        styles += '.fpw-note-cell:hover .fpw-notes { visibility: visible; }';
        styles += '.fpw-notes { visibility: hidden; position: absolute; background-color: #FFFEF2; border: solid 1px #d3d3d3; border-radius: 5px; padding: 5px 10px; white-space: normal; margin: 5px 5px 0 0; box-shadow: 0px 0px 10px lightgray; z-index: 1000;}';
        styles += '#fp-widget .player-team { font-size: 11px; color: #737373; }'
        styles += '#fp-widget-pubDate { font-size: 12px; padding-top: 5px; }';
        styles += '#fp-widget-pubDate img { margin-left: 5px; }';
        styles += 'p.fp-widget-tier { border-bottom: 1px solid #DDD; font-weight: 700; font-family: \'Poppins\', sans-serif;  margin: 0; background-color: #E5E5E5; padding-left: 5px; }';
        styles += '#fp-widget-table table td.fp-widget-tier { font-size: 11px; font-weight: 700; background-color: #E5E5E5; }';
        styles += '.fp-widget-tier tr { margin: 0; padding: 0; border-left: 1px solid #ccc; border-top: 1px solid #ccc; border-collapse: collapse; }';
        styles += '.fpw-footer { font-size: 11px; font-family: \'Poppins\', sans-serif; width: ' + width + '; display: flex; align-items: center; justify-content: space-between; }';
        styles += '.fpw-img-cont { float: left; }';
        styles += '.fpw-player-img { vertical-align: top; border-radius: 5px; margin: 0 5px 5px 0; width: 50px; border: 1px solid #DDD; }';
        styles += '.fpw-player-p { border-bottom: 1px solid #DDD; padding: 10px 0 10px 5px; margin: 0; }';
        styles += '.fpw-cs-pos-div { float: left; padding: 10px; width: ' + columnWidth + '%; min-width: 200px; border: 1px solid #d3d3d3; margin-bottom: -1px; margin-right: -1px; }';
        styles += '#fp-pos-cs > div:nth-of-type(1) { border-left: none; border-right: 1px solid #d3d3d3; margin-right: -1px; }';
        styles += '#fp-widget-table { height: calc(100% - ' + (FPW.tabPositions ? 123 : 50) + 'px); width: 100%; overflow: auto; float: left; box-sizing: content-box; }';
        styles += '#fp-pos-cs { width: 100%; float: left; border-left: 1px solid #d3d3d3; }';
        styles += '.fpw-cheatsheet-rank { font-weight: bold; flex: 0 0 30px; }';
        styles += '.fpw-cheatsheet-pos { margin-left: auto; }';
        styles += '.fpw-cheatsheet-playerDiv {  font-size: 14px; display: flex; align-items: center; }';
        styles += '.fpw-cheatsheet-playerA { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }';
        styles += 'th:hover span[title]:after { content: attr(title);position: absolute;margin-top: -21px;margin-left: -90px;background-color: rgb(0, 0, 0);color: #fff;padding: 2px 5px;border-radius: 3px;font-size: 11px;font-weight: normal; }';
        fpStyles.innerHTML = styles;
    }
}

FPW.init();

